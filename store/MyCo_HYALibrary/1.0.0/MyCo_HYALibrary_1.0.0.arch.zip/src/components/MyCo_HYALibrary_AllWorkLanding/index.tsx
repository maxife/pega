import React, { useState } from "react";

type Row = {
  id: string;
  numeroPolice: string;
  souscripteur: string;
  intermediaire: string,
  tache: string;
  prime: string;
  sp: string;
  statut: string;
  gestionnaire?: string;
  echeance?: string;
  duree?: string;
  branche?: string;
};
const mockRows = [
  {
    id: "4000P234567",
    numeroPolice: "4000P234567",
    souscripteur: "DM Apro",
    intermediaire: "Super courtier",
    statut: "Projet",
    prime: "10 000 €",
    sp: "50%",
    tache: "En négociation"
  },
  {
    id: "4000P234568",
    numeroPolice: "4000P234568",
    souscripteur: "COFAQ",
    intermediaire: "Assuraction",
    statut: "Assuré",
    prime: "25 000 €",
    sp: "60%",
    tache: "Demande d'option"
  },
  {
    id: "4000P234569",
    numeroPolice: "4000P234569",
    souscripteur: "ExaCOM",
    intermediaire: "Courtier SA",
    statut: "Assuré",
    prime: "7 000 €",
    sp: "45%",
    tache: "Demande d'aménagement technique"
  },
  {
    id: "4000P234570",
    numeroPolice: "4000P234570",
    souscripteur: "InterCollect",
    intermediaire: "Jemassure",
    statut: "Projet",
    prime: "15 000 €",
    sp: "40%",
    tache: "En négociation"
  },
  {
    id: "4000P234571",
    numeroPolice: "4000P234571",
    souscripteur: "NEXOCTOM",
    intermediaire: "Jemassure",
    statut: "Projet",
    prime: "15 000 €",
    sp: "40%",
    tache: "En négociation"
  },
  {
    id: "4000P234572",
    numeroPolice: "4000P234572",
    souscripteur: "ALGOREL",
    intermediaire: "Courtier&Co",
    statut: "Assuré",
    prime: "30 000 €",
    sp: "70%",
    tache: "Demande d'option"
  }
];

export default function Index() {
  const [selectedRow, setSelectedRow] = useState<Row | null>(null);

  return (
    <div style={{ display: "flex", gap: "16px" }}>

      {/* TABLEAU */}
      <div style={{ flex: 4 }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th>N° police</th>
              <th>Souscripteur</th>
              <th>Intermédiaire</th>
              <th>Statut</th>
              <th>Prime</th>
              <th>S/P</th>
              <th>Tâche / Étape</th>
              <th>Détails</th>
            </tr>
          </thead>

          <tbody>
            {mockRows.map((row: Row) => (
              <tr key={row.id}>
                <td>{row.id}</td>
                <td>{row.souscripteur}</td>
                <td>{row.intermediaire}</td>
                <td>{row.statut}</td>
                <td>{row.prime}</td>
                <td>{row.sp}</td>
                <td>{row.tache}</td>
                <td>
                  <button
                    type="button"
                    onClick={() => setSelectedRow(row)}
                    title="Afficher le détail"
                    style={{
                      cursor: "pointer",
                      background: "none",
                      border: "none"
                    }}
                  >
                    🔍
                  </button>
                </td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* PANNEAU DROIT */}
      <div style={{
        flex: 1,
        border: "1px solid #ccc",
        padding: "12px",
        borderRadius: "6px"
      }}>
        {selectedRow ? (
          <>
            <h3>{selectedRow.souscripteur}</h3>
            <p><strong>Gestionnaire :</strong> {selectedRow.gestionnaire}</p>
            <p><strong>Échéance :</strong> {selectedRow.echeance}</p>
            <p><strong>Durée :</strong> {selectedRow.duree}</p>
            <p><strong>Branche :</strong> {selectedRow.branche}</p>
          </>
        ) : (
          <p>Sélectionnez une ligne</p>
        )}
      </div>
    </div>
  );
}
